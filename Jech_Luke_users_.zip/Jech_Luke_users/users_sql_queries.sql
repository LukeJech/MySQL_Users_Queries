select * from users
ORDER BY first_name DESC
